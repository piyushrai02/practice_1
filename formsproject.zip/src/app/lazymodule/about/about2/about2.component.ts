import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about2',
  templateUrl: './about2.component.html',
  styleUrls: ['./about2.component.css']
})
export class About2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
