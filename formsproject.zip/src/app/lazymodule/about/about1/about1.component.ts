import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about1',
  templateUrl: './about1.component.html',
  styleUrls: ['./about1.component.css']
})
export class About1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
