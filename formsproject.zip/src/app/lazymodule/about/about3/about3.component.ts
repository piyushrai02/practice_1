import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about3',
  templateUrl: './about3.component.html',
  styleUrls: ['./about3.component.css']
})
export class About3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
