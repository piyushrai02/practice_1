export class Blog {
    id:Number;
    name:String;
    address:any;
    mobile:Number;  
}
